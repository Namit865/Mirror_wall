import 'package:flutter/material.dart';
import 'package:mirror_wall/providers/connectivity_provider.dart';
import 'package:mirror_wall/providers/web_provider.dart';
import 'package:mirror_wall/screens/mainscreen.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => WebProvider()),
        ChangeNotifierProvider(create: (context) => ConnectivityProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      title: 'Educational & Entertainment Aggregator',
      home: const MainScreen()
    );
  }
}
