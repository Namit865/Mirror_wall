import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import '../model/variables.dart';

class ConnectivityProvider extends ChangeNotifier {

  Connectivitymodel connectivitymodel = Connectivitymodel(Progress: "Offline");

  Connectivity connectivity = Connectivity();

  void checkConnection() {
    connectivity.onConnectivityChanged.listen((ConnectivityResult connectivityResult) {
      if (connectivityResult == ConnectivityResult.mobile ||
          connectivityResult == ConnectivityResult.wifi) {
        connectivitymodel.Progress = "Online";
        notifyListeners();
      }
      else {
        connectivitymodel.Progress = "Offline";
        notifyListeners();
      }
    });
  }
}
