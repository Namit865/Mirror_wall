import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import '../model/web_variables.dart';

class WebProvider extends ChangeNotifier {
  InAppWebViewController? inAppWebViewController;
  PullToRefreshController? pullToRefreshController;

  List<Website> websites = [
    Website(name: 'Wikipedia', url: 'https://www.wikipedia.org'),
    Website(name: 'W3Schools', url: 'https://www.w3schools.com'),
    Website(name: 'javaPoint', url: 'https://www.javatpoint.com/'),
    Website(
        name: 'tutorialPoint', url: 'https://www.tutorialspoint.com/index.htm')
  ];

  List<Website> platforms = [
    Website(name: 'Netflix', url: 'https://www.netflix.com'),
    Website(name: 'Amazon Prime', url: 'https://www.amazon.com/prime'),
    Website(name: 'Disney+ Hotstar', url: 'https://www.hotstar.com'),
    Website(name: 'Sony Liv', url: 'https://www.sonyliv.com'),
  ];
  List<Website> searchEngines = [
    Website(name: 'Google', url: 'www.google.com'),
    Website(name: 'Uc Browser', url: 'www.ucbrowser.com'),
    Website(name: 'Mozila FireFox', url: 'www.mozilafirefox.com'),
  ];

  void initController(InAppWebViewController controller) {
    inAppWebViewController = controller;
    notifyListeners();
  }

  void pullRefresh() {
    pullToRefreshController = PullToRefreshController(
      options: PullToRefreshOptions(color: Colors.red),
      onRefresh: () {
        inAppWebViewController!.reload();
      },
    );
    notifyListeners();
  }

  Future<void> homepage(String uri) async {
    await inAppWebViewController!.loadUrl(
      urlRequest: URLRequest(url: Uri.parse(uri)),
    );
    notifyListeners();
  }

  stopRefresh() {
    pullToRefreshController!.endRefreshing();
    notifyListeners();
  }

  Future<void> forward() async {
    if (await inAppWebViewController!.canGoForward()) {
      await inAppWebViewController!.goForward();
    }
    notifyListeners();
  }

  Future<void> backward() async {
    if (await inAppWebViewController!.canGoBack()) {
      await inAppWebViewController!.goBack();
    }
    notifyListeners();
  }

  Future<void> Refresh() async {
    await inAppWebViewController!.reload();
    notifyListeners();
  }
}
