import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:mirror_wall/providers/web_provider.dart';
import 'package:provider/provider.dart';

class WebviewPage extends StatelessWidget {
  final String url;

  const WebviewPage({super.key, required this.url, required name});
  @override



  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Web Content'),
      ),
      body: InAppWebView(
        pullToRefreshController: Provider.of<WebProvider>(context).pullToRefreshController,
        initialUrlRequest: URLRequest(url: Uri.parse(url)),
        onLoadStart: (controller, url) {
          Provider.of<WebProvider>(context,listen: false).initController(controller);
        },
        onLoadStop: (controller, url) {
          Provider.of<WebProvider>(context,listen: false).stopRefresh();
        },
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () async {
              await Provider.of<WebProvider>(context, listen: false).backward();
            },
            child: const Icon(
              Icons.arrow_back_rounded,
            ),
          ),
          const SizedBox(width: 20,),
          FloatingActionButton(
            onPressed: () async {
              await Provider.of<WebProvider>(context, listen: false).forward();
            },
            child: const Icon(
              Icons.arrow_forward,
            ),
          ),
          const SizedBox(width: 20,),
          FloatingActionButton(
            onPressed: () async {
              await Provider.of<WebProvider>(context, listen: false).Refresh();
            },
            child: const Icon(
              Icons.restart_alt,
            ),
          ),
          const SizedBox(width: 20,),
          FloatingActionButton(
            onPressed: () async {
              await Provider.of<WebProvider>(context, listen: false)
                  .homepage(url);
            },
            child: const Icon(
              Icons.home,
            ),
          ),
        ],
      ),
    );
  }
}
