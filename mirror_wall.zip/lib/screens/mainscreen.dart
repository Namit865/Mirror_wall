import 'package:flutter/material.dart';
import 'package:mirror_wall/providers/connectivity_provider.dart';
import 'package:mirror_wall/screens/educationscreen.dart';
import 'package:mirror_wall/screens/entertainment_screen.dart';
import 'package:provider/provider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  void initState() {
    super.initState();
    Provider.of<ConnectivityProvider>(context, listen: false).checkConnection();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Two tabs (Education and Entertainment)
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Mirror Wall',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
          ),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Education'),
              Tab(text: 'Entertainment'),
            ],
          ),
        ),
        body: (Provider.of<ConnectivityProvider>(context)
                    .connectivitymodel
                    .Progress ==
                "Offline")
            ? const Center(
                child: Text("No Internet Connection",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    )),
              )
            : const TabBarView(
                children: [
                  Education(),
                  Entertainment(),
                ],
              ),
      ),
    );
  }
}
