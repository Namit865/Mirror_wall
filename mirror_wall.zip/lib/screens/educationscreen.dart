import 'package:flutter/material.dart';
import 'package:mirror_wall/providers/web_provider.dart';
import 'package:mirror_wall/screens/web_view.dart';
import 'package:provider/provider.dart';

class Education extends StatefulWidget {
  const Education({super.key});

  @override
  State<Education> createState() => _EducationState();
}

class _EducationState extends State<Education> {
  @override
  Widget build(BuildContext context) {
    final websiteProvider = Provider.of<WebProvider>(context);

    return ListView.builder(
      itemCount: websiteProvider.websites.length,
      itemBuilder: (context, index) {
        final website = websiteProvider.websites[index];
        return Card(
          shadowColor: Colors.white,
          elevation: 3,
          margin: const EdgeInsets.all(8),
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WebviewPage(url: website.url,name:website.name),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                website.name,
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ),
        );
      },
    );
  }
}
