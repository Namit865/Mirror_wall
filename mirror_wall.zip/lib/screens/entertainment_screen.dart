import 'package:flutter/material.dart';
import 'package:mirror_wall/providers/web_provider.dart';
import 'package:mirror_wall/screens/web_view.dart';
import 'package:provider/provider.dart';

class Entertainment extends StatefulWidget {
  const Entertainment({super.key});

  @override
  State<Entertainment> createState() => _EntertainmentTabState();
}

class _EntertainmentTabState extends State<Entertainment> {
  @override
  Widget build(BuildContext context) {

    return ListView.builder(
      itemCount: Provider.of<WebProvider>(context).platforms.length,
      itemBuilder: (context, index) {
        final platform = Provider.of<WebProvider>(context).platforms[index];
        return Card(
          shadowColor: Colors.white,
          elevation: 3,
          margin: const EdgeInsets.all(8),
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WebviewPage(url: platform.url, name: platform.name,),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                platform.name,
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ),
        );
      },
    );
  }
}
