class Connectivitymodel {
  String Progress;

  Connectivitymodel({required this.Progress});
}
