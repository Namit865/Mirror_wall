class Website {
  final String name;
  final String url;

  Website({required this.name, required this.url});
}